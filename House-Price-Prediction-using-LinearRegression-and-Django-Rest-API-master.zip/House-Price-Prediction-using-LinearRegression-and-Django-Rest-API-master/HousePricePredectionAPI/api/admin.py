from django.contrib import admin
from .models import price

# Register your models here.
admin.site.register(price)